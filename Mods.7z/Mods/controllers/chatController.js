// Dependencies
// import OpenAI from 'openai';
import dotenv from 'dotenv';
dotenv.config();
import fs from "fs";

// Creation of the OpenAI client instance
/*
const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});
OpenAI
// Controller function
const handleChat = async (req, res) => {
    // Error handling just in-case
    try {
        const { message } = req.body;

        if (!message) {
            return res.status(400).json({error: "Message is required"});
        }
        // Model use for OpenAI
        const response = await openai.chat.completions.create({
            model: "gpt-3.5-turbo",
            messages: [{ role: "user", content: message }],
        });

        // Extracting the response from AI
        const reply = response.choices[0].message.content;

        res.json({ reply });
    } catch (error) {
        console.error("OpenAI Error:", error);
        res.status(500).json({ error: "Something went wrong with OpenAI" });
    }
};*/

// Load dataset once
const dataset = JSON.parse(fs.readFileSync("./data/educationalDataset.json", "utf-8"));

const handleChat = async (req, res) => {
    // Error handling just in-case
    try {
        const {message} = req.body;

        if (!message) {
            return res.status(400).json({error: "Message is required"});
        }

        // Simple keyword search
        const found = dataset.find(item =>
            message.toLowerCase().includes(item.question.toLowerCase())
        );

        const reply = found
            ? found.answer
            : "Sorry, I don't know the answer to that yet.";

        res.json({ reply });

    } catch (error) {
        console.error("OpenAI Error:", error);
        res.status(500).json({error: "Something went wrong"});
    }
};

// Exporting the function
export default { handleChat };
