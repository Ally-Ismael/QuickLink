// Dependencies
import express from 'express';
import chatController from '../controllers/chatController.js';


// Creating the router
const router = express.Router();

// Defining the route
router.post('/', chatController.handleChat);

// Exporting the route
export default router;