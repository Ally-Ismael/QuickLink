// Dependencies
import express from 'express';
import dotenv from 'dotenv';
dotenv.config();

// Initialization
const app = express();

// Middleware
app.use(express.json());

// From routes folder
import chatRoutes from './routes/chat.js';
app.use('/chat', chatRoutes);

// Route
app.get('/', (req, res) => {
    res.send('Server is working');
});

// Starting the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`)
});